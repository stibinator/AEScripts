# AEScripts

Tools that I've created for improving workflows in After Effects. The released versions are available at https:blob.pureandapplied.com.au, along with installation instructions and notes on how to use them.
